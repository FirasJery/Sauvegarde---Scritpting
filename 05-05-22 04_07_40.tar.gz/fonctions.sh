#!/bin/bash

show_usage(){
  echo "sauvegarde.sh: [-h][-g][-m][-v][-n][-r][-a][-s] chemin..."
}

help(){
  cat help.txt
}

sizeModified24(){
  find /home/penguin/ -mtime -1 -exec du -ch {} + | grep total
  nb=$(find /home/penguin/ -mtime -1 | wc -l)
  echo "$nb fichiers modifiées dans les dernières 24 heures."
}

zipLast24(){
  #find /home/penguin/Desktop/Project/Scripting/ -mtime -1 -execdir zip 'Archive'.zip {} +
  #zip -d Archive.zip .zip
  #zip -d Archive.zip .zip.zip
  #zip -d Archive.zip .zip.zip.zip
  t=$(date +"%d-%m-%y %T")
  find /home/penguin/Desktop/Project/Scripting/ -mtime -1 -execdir tar -czvf "Archive".tar.gz {} +
  echo $t > time.txt
  mv Archive.tar.gz "$t.tar.gz"
  #tar -vf Archive.tar --delete ./.zip
}

renameTar(){
  t=$(date +"%d-%m-%y %T")
  old=$(find /home/penguin/Desktop/Project/Scripting/ -type f -name "*.tar.gz")
  substring=$(echo $old | cut -c)
  echo $substring
}
echo "Memes"
