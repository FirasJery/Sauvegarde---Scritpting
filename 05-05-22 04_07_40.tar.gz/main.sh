#!/bin/bash
source fonctions.sh

while getopts "nar" option
do
  echo "Getopts a trouvé $option"
  case $option in
    n)
      sizeModified24
      ;;
    a)
      zipLast24
      ;;
    r)
      renameTar
      ;;
    *)
      show_usage
      ;;
  esac
done
exit 0
